mpicc parallel_jacobi.c -o parallel_jacobi -lm
#mpiexec -n 2 parallel_jacobi

