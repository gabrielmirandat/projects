gcc ex1.c -o ex1

mpicc ex2.c 1_cio.c -o ex2

mpicc ex3.c 1_cio.c -o ex3
