mpicc parallel_trap.c 1_cio.c -o parallel_trap
mpicc assig1.c -o assig1
# mpiexec -n 4 parallel_trap
# mpiexec -n 4 assign1
