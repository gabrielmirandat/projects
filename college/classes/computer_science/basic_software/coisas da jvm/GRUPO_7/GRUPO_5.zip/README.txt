Gabriel Martins de Miranda 	- 130111350 
Marina Martins de Miranda 	- 110132351
Victor Fernandes Uriarte 	- 110021193 
Guilherme Neves Souza 		- 130113182
Elton Araujo de Castro 		- 110028384


LINUX
gcc -std=c99 leitor_exibidor.c -o leitor_exibidor -lm
./leitor_exibidor <arquivo.class> f|t
ou 
chmod a+x executa_nosso
./executa_nosso

WINDOWS
gcc -std=c99 leitor_exibidor.c -o leitor_exibidor -lm -static-libgcc -static-libstdc++
leitor_exibidor <arquivo.class> f|t