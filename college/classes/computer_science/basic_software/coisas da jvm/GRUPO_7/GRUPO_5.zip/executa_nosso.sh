gcc -std=c99 leitor_exibidor.c -o leitor_exibidor -lm
./leitor_exibidor HelloWorld.class f