var structoperand =
[
    [ "prox", "structoperand.html#a49e5a5dbe02eaa10b1a29b71106f9910", null ],
    [ "type", "structoperand.html#a8af3746223d14253f5b287d236f59ce4", null ],
    [ "value", "structoperand.html#a4112f16b41c272f45499c809391b17a2", null ]
];