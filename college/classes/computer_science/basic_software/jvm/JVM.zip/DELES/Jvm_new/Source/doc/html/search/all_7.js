var searchData=
[
  ['handleobject',['handleObject',['../interpreter_8c.html#a087a4ba00043fe2d831ccf04b183a0b5',1,'handleObject(METHOD_DATA *method, THREAD *thread, JVM *jvm):&#160;interpreter.c'],['../interpreter_8h.html#a71f70628eeae78d6f63ae10b87a0a8bf',1,'handleObject(METHOD_DATA *, THREAD *, JVM *):&#160;interpreter.c']]],
  ['handler_5fpc',['handler_pc',['../structexception__table__type.html#a168dd215f7eea25beaf31316f15b48b7',1,'exception_table_type']]],
  ['handlestack',['handleStack',['../interpreter_8c.html#ac9f409a905c3c48cd6921bcb144b88ac',1,'handleStack(METHOD_DATA *method, THREAD *thread, JVM *jvm):&#160;interpreter.c'],['../interpreter_8h.html#a0464f031ce20c82df647d659529e3cbb',1,'handleStack(METHOD_DATA *, THREAD *, JVM *):&#160;interpreter.c']]],
  ['heap_5farea',['heap_area',['../structheap__area.html',1,'heap_area'],['../core_8h.html#a8aa4d8af3cc19c82a17fa714d533cb8f',1,'HEAP_AREA():&#160;core.h']]],
  ['heap_5fjvm',['heap_jvm',['../structjvm.html#aaa2c1b91d2f8feef91b7e1e8552a873f',1,'jvm']]],
  ['high_5fbytes',['high_bytes',['../structvalue.html#a670628f51376fadc6cd3c7aa2076dd95',1,'value::high_bytes()'],['../structconst_pool_inf.html#ab116ef79f6cae5784e038805c26f2d20',1,'constPoolInf::high_bytes()']]]
];
