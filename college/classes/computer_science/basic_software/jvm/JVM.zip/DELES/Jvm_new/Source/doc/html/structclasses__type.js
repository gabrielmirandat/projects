var structclasses__type =
[
    [ "inner_class_access_flags", "structclasses__type.html#a6e2e0b5e77749572a331f070924620ad", null ],
    [ "inner_class_info_index", "structclasses__type.html#a8ee3c154b6031adfa97fccc80d7a76ff", null ],
    [ "inner_name_index", "structclasses__type.html#acd3c408b30a72b1ae22a56fb8642684c", null ],
    [ "outer_class_info_index", "structclasses__type.html#a8a32528b616cd9d1cfc3278e8c942f8f", null ]
];