var searchData=
[
  ['d2t',['d2T',['../interpreter_8c.html#a560b57e699e82fbfeb88e79fdd79be31',1,'d2T(METHOD_DATA *method, THREAD *thread, JVM *jvm):&#160;interpreter.c'],['../interpreter_8h.html#a66442e680b4aa2b68bcd6ea84fd10d62',1,'d2T(METHOD_DATA *, THREAD *, JVM *):&#160;interpreter.c']]]
];
