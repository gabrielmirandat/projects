package javaTeste;
import javaTeste.HelloWorldObject;

public class StaticTeste {

    public static void main(String[] args) {
    	int a = HelloWorldObject.field;
    	a = a*2;
    }
    
}