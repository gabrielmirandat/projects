var searchData=
[
  ['f2t',['f2T',['../interpreter_8c.html#ade1c69d439aa79742d9144d6eb5616c5',1,'f2T(METHOD_DATA *method, THREAD *thread, JVM *jvm):&#160;interpreter.c'],['../interpreter_8h.html#ae9dfab8fc6dd72ad8368fa5224937535',1,'f2T(METHOD_DATA *, THREAD *, JVM *):&#160;interpreter.c']]],
  ['freearrays',['freeArrays',['../core_8h.html#afa9de2a389a6ad80bf97ffa0a5eef402',1,'core.h']]],
  ['freeattribute',['freeAttribute',['../_leit_exib_8h.html#a34567e888188bcc0c458a8a2a53d159c',1,'freeAttribute(attribute_info *, ClasseDeArquivo *):&#160;LeitorExibidor.c'],['../_leitor_exibidor_8c.html#a24d7f0e5e7f8788a8d2d42be09c7701e',1,'freeAttribute(attribute_info *attr, ClasseDeArquivo *ca):&#160;LeitorExibidor.c']]],
  ['freeclassdata',['freeClassData',['../core_8h.html#ab34a58b2e6a6901430c3c6c025c5c5c6',1,'core.h']]],
  ['freeclassedearquivo',['freeClasseDeArquivo',['../_leit_exib_8h.html#a4dfb173145bef4fe116eb3e89c069a51',1,'freeClasseDeArquivo(ClasseDeArquivo *):&#160;LeitorExibidor.c'],['../_leitor_exibidor_8c.html#a06542c7fe5be4bfbbe17d08cf541aac4',1,'freeClasseDeArquivo(ClasseDeArquivo *ca):&#160;LeitorExibidor.c']]],
  ['freeconstantepool',['freeCONSTANTEPool',['../_leit_exib_8h.html#a4a9c912f7555fe6f6e34e59442bfb94b',1,'freeCONSTANTEPool(ClasseDeArquivo *):&#160;LeitorExibidor.c'],['../_leitor_exibidor_8c.html#addae5433cb88b774299b1bfb62f7da3f',1,'freeCONSTANTEPool(ClasseDeArquivo *ca):&#160;LeitorExibidor.c']]],
  ['freefields',['freeFields',['../_leit_exib_8h.html#a9f52c199e8b95e8b94e3d0fd0551577c',1,'freeFields(ClasseDeArquivo *):&#160;LeitorExibidor.c'],['../_leitor_exibidor_8c.html#a7a27c4cd78cdbdc4b6ba19628a72995a',1,'freeFields(ClasseDeArquivo *ca):&#160;LeitorExibidor.c']]],
  ['freeframe',['freeFrame',['../core_8h.html#abbc22effef4dba84ae83d5e6d1e3da4b',1,'core.h']]],
  ['freeheap',['freeHeap',['../core_8h.html#a4bfc9fc3dd56d8ad9327db10219d2ae3',1,'core.h']]],
  ['freejvmstack',['freeJvmStack',['../core_8h.html#a135eacb54215249d2fb634c920c16d99',1,'core.h']]],
  ['freemethodarea',['freeMethodArea',['../core_8h.html#a4074439f529db8ac5c67c1064e0b1b37',1,'core.h']]],
  ['freemethods',['freeMethods',['../_leit_exib_8h.html#a909677da966f9a65e4c4d142d2394154',1,'freeMethods(ClasseDeArquivo *):&#160;LeitorExibidor.c'],['../_leitor_exibidor_8c.html#af557d35c207e32b164b8b85bcd90e421',1,'freeMethods(ClasseDeArquivo *ca):&#160;LeitorExibidor.c']]],
  ['freeobjects',['freeObjects',['../core_8h.html#a769094478f2fd98914bfb300f04982f6',1,'core.h']]],
  ['freeoperandstack',['freeOperandStack',['../core_8h.html#a360c5e8ed32f1b8c1222fe180f02f3cc',1,'core.h']]],
  ['freethreads',['freeThreads',['../core_8h.html#ae038c26bdcbf2be5dca8839cd6c6b5f4',1,'core.h']]],
  ['freevariables',['freeVariables',['../core_8h.html#ab6c8ef9f9ac6072962115bd3085d4b4b',1,'core.h']]]
];
