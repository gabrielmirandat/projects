var structobject =
[
    [ "class_data_reference", "structobject.html#af7136e313255a7d1efdcf775c9f6c412", null ],
    [ "instance_variables", "structobject.html#ad02cb265ba006796debd79c5e22902d3", null ],
    [ "prox", "structobject.html#adc7a300d54dbdc7f5a72f145b30ff3da", null ]
];