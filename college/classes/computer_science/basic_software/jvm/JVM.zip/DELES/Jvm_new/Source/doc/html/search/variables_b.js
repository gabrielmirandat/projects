var searchData=
[
  ['nameandtype',['NameAndType',['../structconst_pool_inf.html#addb54edaecbb6a09ef4799c98134332a',1,'constPoolInf']]],
  ['nomeclasse',['nomeClasse',['../struct_d_a_d_o_s___c_l_a_s_s_e.html#aa36d42ba9b426675415d1da6c02e4420',1,'DADOS_CLASSE']]],
  ['number_5fof_5fclasses',['number_of_classes',['../structattribute__info.html#acf309770753a9a9e7cf0b91fb4dd45db',1,'attribute_info']]],
  ['number_5fof_5fexceptions',['number_of_exceptions',['../structattribute__info.html#a7c0c2c58d833f7b63d0b6ab483e537f1',1,'attribute_info']]]
];
