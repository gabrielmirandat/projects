var annotated =
[
    [ "array", "structarray.html", "structarray" ],
    [ "attribute_info", "structattribute__info.html", "structattribute__info" ],
    [ "ClasseDeArquivo", "struct_classe_de_arquivo.html", "struct_classe_de_arquivo" ],
    [ "classes_type", "structclasses__type.html", "structclasses__type" ],
    [ "constPoolInf", "structconst_pool_inf.html", "structconst_pool_inf" ],
    [ "DADOS_CLASSE", "struct_d_a_d_o_s___c_l_a_s_s_e.html", "struct_d_a_d_o_s___c_l_a_s_s_e" ],
    [ "exception_table_type", "structexception__table__type.html", "structexception__table__type" ],
    [ "field_data", "structfield__data.html", "structfield__data" ],
    [ "field_info", "structfield__info.html", "structfield__info" ],
    [ "frame", "structframe.html", "structframe" ],
    [ "heap_area", "structheap__area.html", "structheap__area" ],
    [ "jvm", "structjvm.html", "structjvm" ],
    [ "line_number_table_type", "structline__number__table__type.html", "structline__number__table__type" ],
    [ "local_variable_table_type", "structlocal__variable__table__type.html", "structlocal__variable__table__type" ],
    [ "method_data", "structmethod__data.html", "structmethod__data" ],
    [ "method_info", "structmethod__info.html", "structmethod__info" ],
    [ "object", "structobject.html", "structobject" ],
    [ "operand", "structoperand.html", "structoperand" ],
    [ "thread", "structthread.html", "structthread" ],
    [ "value", "structvalue.html", "structvalue" ],
    [ "variable", "structvariable.html", "structvariable" ]
];