var searchData=
[
  ['ref',['Ref',['../structconst_pool_inf.html#ad0c502e47bccc75b8e939e5ccd1a8a16',1,'constPoolInf']]],
  ['reference',['reference',['../structvalue.html#ab277933041ff972104180fda5190a425',1,'value::reference()'],['../structvalue.html#a97a92c9e274a9166f7ae32164a06fe1d',1,'value::reference()']]],
  ['referencia_5fcarregadorclasse',['referencia_carregadorClasse',['../struct_d_a_d_o_s___c_l_a_s_s_e.html#af50666164c0a79d63ff831010e8318c9',1,'DADOS_CLASSE']]],
  ['return_5faddress',['return_address',['../structvalue.html#ae154453352d31839cbe33fca89fc98aa',1,'value']]],
  ['returnaddress',['ReturnAddress',['../structvalue.html#a264ea0eb8eca9c9698c66c7412e8ca88',1,'value']]],
  ['runtime_5fconstant_5fpool',['runtime_constant_pool',['../struct_d_a_d_o_s___c_l_a_s_s_e.html#a0c018490460fc694fc1bcdeddbd49e02',1,'DADOS_CLASSE']]]
];
