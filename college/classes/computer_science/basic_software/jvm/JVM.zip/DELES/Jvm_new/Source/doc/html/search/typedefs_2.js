var searchData=
[
  ['dados_5fclasse',['DADOS_CLASSE',['../core_8h.html#a116ede3eb3d97f03336302025379d1c7',1,'core.h']]]
];
