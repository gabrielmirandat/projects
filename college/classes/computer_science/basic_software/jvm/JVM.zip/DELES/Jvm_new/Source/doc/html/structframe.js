var structframe =
[
    [ "current_constant_pool", "structframe.html#a44e706fb58a455a533afd748c097c9d0", null ],
    [ "local_variables", "structframe.html#afb48efe21a0642a382ef875628272cfd", null ],
    [ "operand_stack", "structframe.html#a0e69123161d7ee38be16d922f09dc320", null ],
    [ "prox", "structframe.html#ad5c645b97d4a17c7352bf29e7396cea4", null ]
];