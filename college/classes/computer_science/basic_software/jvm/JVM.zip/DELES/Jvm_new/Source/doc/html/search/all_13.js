var searchData=
[
  ['value',['value',['../structvalue.html',1,'value'],['../structoperand.html#a4112f16b41c272f45499c809391b17a2',1,'operand::value()'],['../structvariable.html#a163435f346185d4f2d8d05a78dde5bef',1,'variable::value()'],['../core_8h.html#ad5d0e2bb91a9e28f920452e088b6462b',1,'VALUE():&#160;core.h']]],
  ['var',['var',['../structfield__data.html#a6eb4ec12db5dba2140fff01c6d0439f8',1,'field_data']]],
  ['variable',['variable',['../structvariable.html',1,'variable'],['../core_8h.html#a85b40991452ad00efae1784148c94402',1,'VARIABLE():&#160;core.h']]],
  ['variaveisclasse',['variaveisClasse',['../struct_d_a_d_o_s___c_l_a_s_s_e.html#a61814affa4242c9de4ab4380163ae315',1,'DADOS_CLASSE']]],
  ['verifyaccessflags',['verifyAccessFlags',['../checker_8c.html#a3e295f32f754594e38f31297afebca97',1,'verifyAccessFlags(ClasseDeArquivo *cf):&#160;checker.c'],['../checker_8h.html#aad8e6070923c46681f8b2144b70c789a',1,'verifyAccessFlags(ClasseDeArquivo *):&#160;checker.c']]],
  ['verifybytecode',['verifyBytecode',['../checker_8c.html#a5c524d6b071cd201765ed95b10b9eedd',1,'verifyBytecode(attribute_info *attr, ClasseDeArquivo *cf):&#160;checker.c'],['../checker_8h.html#a85b7fdf6ca41f7ae066becc961a2892b',1,'verifyBytecode(attribute_info *, ClasseDeArquivo *):&#160;checker.c']]],
  ['verifyclassfile',['verifyClassfile',['../checker_8c.html#a0dcac7578c8c1cf7ef0f7b6fffe5ae24',1,'verifyClassfile(ClasseDeArquivo *cf):&#160;checker.c'],['../checker_8h.html#a496eaab3cf87436d88f45f408fcc7b54',1,'verifyClassfile(ClasseDeArquivo *):&#160;checker.c']]],
  ['verifyconstantpool',['verifyConstantPool',['../checker_8c.html#a6ecc7358598704e5b4e9d77f06495482',1,'verifyConstantPool(ClasseDeArquivo *cf):&#160;checker.c'],['../checker_8h.html#ad1feb70bcfb835f9472fda62313ffbb6',1,'verifyConstantPool(ClasseDeArquivo *):&#160;checker.c']]],
  ['verifyoverridemethodfinal',['verifyOverrideMethodFinal',['../checker_8c.html#a4bbffc69c6cd821aebc4c480ffd3aec1',1,'verifyOverrideMethodFinal(ClasseDeArquivo *cf, JVM *jvm):&#160;checker.c'],['../checker_8h.html#aeeaf21856554a50ea68bb1a9fcd69c2b',1,'verifyOverrideMethodFinal(ClasseDeArquivo *, JVM *):&#160;checker.c']]],
  ['verifysuperfinal',['verifySuperFinal',['../checker_8c.html#a7b952615631393d4b96a3eafe88cb3e7',1,'verifySuperFinal(ClasseDeArquivo *cf, JVM *jvm):&#160;checker.c'],['../checker_8h.html#aed60e642c76864b5b3b00950a8296a2d',1,'verifySuperFinal(ClasseDeArquivo *, JVM *):&#160;checker.c']]]
];
