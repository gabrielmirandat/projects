var structconst_pool_inf =
[
    [ "bytes", "structconst_pool_inf.html#ad855f3fa643b42a9f2506f06d2f74310", null ],
    [ "bytes", "structconst_pool_inf.html#a6e7de138b8c2f5514813538787f73c16", null ],
    [ "Class", "structconst_pool_inf.html#adb4639fcbfae6547548f36dac46a1ce5", null ],
    [ "descriptor_index", "structconst_pool_inf.html#a01d1f403e7ed5762b986ae2fe6e7db4b", null ],
    [ "high_bytes", "structconst_pool_inf.html#ab116ef79f6cae5784e038805c26f2d20", null ],
    [ "indicador_nome", "structconst_pool_inf.html#a2f80c7393ff5829654d7418b7264110a", null ],
    [ "indicador_nome_e_tipo", "structconst_pool_inf.html#adcd281157000a467608ba65cf1a6efb6", null ],
    [ "indicador_string", "structconst_pool_inf.html#a0d09a4566d526db83cd87836f18df28c", null ],
    [ "Integer_Float", "structconst_pool_inf.html#a9cc60d2e41859cb617704d61374ddb74", null ],
    [ "length", "structconst_pool_inf.html#a3c4be7f5456b58187d9695bb1d3c8871", null ],
    [ "Long_Double", "structconst_pool_inf.html#a25e99a2c4f18168165ed83b5f4cfe234", null ],
    [ "low_bytes", "structconst_pool_inf.html#a15471799757777098756cc8ec1cd9a3c", null ],
    [ "NameAndType", "structconst_pool_inf.html#addb54edaecbb6a09ef4799c98134332a", null ],
    [ "Ref", "structconst_pool_inf.html#ad0c502e47bccc75b8e939e5ccd1a8a16", null ],
    [ "String", "structconst_pool_inf.html#adfd1e8831065142d9deb97e7bd79c356", null ],
    [ "tag", "structconst_pool_inf.html#a6ea639ac2bd081a75fb00ee2231b5bf3", null ],
    [ "u", "structconst_pool_inf.html#ad39a609c73e52b6faa7d2f1a29a14d28", null ],
    [ "Utf8", "structconst_pool_inf.html#abf7874c7fbecc53ed38466b1ff897746", null ]
];