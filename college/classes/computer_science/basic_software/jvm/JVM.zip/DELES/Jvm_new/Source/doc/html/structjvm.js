var structjvm =
[
    [ "heap_jvm", "structjvm.html#aaa2c1b91d2f8feef91b7e1e8552a873f", null ],
    [ "method_area_jvm", "structjvm.html#ac8c89a213f0d332aff40faa2661b97e3", null ],
    [ "thread_jvm", "structjvm.html#a95875933adbaab4bef10b00738ba0722", null ]
];