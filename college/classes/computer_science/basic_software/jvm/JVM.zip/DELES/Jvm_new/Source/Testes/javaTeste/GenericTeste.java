package javaTeste;

public class GenericTeste {
	
	public static void main(String[] args) {
		/*float f1=10, f2=20;
		double d1=10, d2=20;
		long l1=10, l2=20;
		
		f2 = f1*f2;
		f2 = f2/f1;
		
		d2 = d1*d2;
		d2 = d2/d1;
		
		l2 = l1*l2;
		l2 = l2/l1;*/
		
		int a=0, b=0;
		if (a != 1) {
			a = 1;
		} else {
			b = 1;
		}
	}
	
}