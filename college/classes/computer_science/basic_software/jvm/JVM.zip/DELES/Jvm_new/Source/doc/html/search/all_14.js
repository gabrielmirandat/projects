var searchData=
[
  ['wide',['wide',['../opcode_8h.html#a20c48cc7bb301134c9da955ae6c1f823',1,'opcode.h']]],
  ['wide_5f',['wide_',['../interpreter_8c.html#a94f443e0efca453296685ddc82ff1358',1,'wide_(METHOD_DATA *method, THREAD *thread, JVM *jvm):&#160;interpreter.c'],['../interpreter_8h.html#a33e392041d4c22854ca1b937c8fc58a8',1,'wide_(METHOD_DATA *, THREAD *, JVM *):&#160;interpreter.c']]],
  ['widejump',['widejump',['../interpreter_8c.html#ae92a4faa052510290febb645cb54c952',1,'widejump(METHOD_DATA *method, THREAD *thread, JVM *jvm):&#160;interpreter.c'],['../interpreter_8h.html#a27d5c86f88efdae786cac16e33cc3834',1,'widejump(METHOD_DATA *, THREAD *, JVM *):&#160;interpreter.c']]]
];
