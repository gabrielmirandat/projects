var struct_d_a_d_o_s___c_l_a_s_s_e =
[
    [ "classfile", "struct_d_a_d_o_s___c_l_a_s_s_e.html#a04a5c6ada8a199cc0f66130e8f3fd0db", null ],
    [ "field_data", "struct_d_a_d_o_s___c_l_a_s_s_e.html#a6a524c5e2a3eda5b548ee3cf703c727d", null ],
    [ "instanceClasse", "struct_d_a_d_o_s___c_l_a_s_s_e.html#a3e8be397f59bd8130a2d3df976af3830", null ],
    [ "method_data", "struct_d_a_d_o_s___c_l_a_s_s_e.html#a75c522131e8a7325da50f22f8c373ffa", null ],
    [ "modifiers", "struct_d_a_d_o_s___c_l_a_s_s_e.html#a49b8ef228c1e9116fa30acb28a3b6402", null ],
    [ "nomeClasse", "struct_d_a_d_o_s___c_l_a_s_s_e.html#aa36d42ba9b426675415d1da6c02e4420", null ],
    [ "prox", "struct_d_a_d_o_s___c_l_a_s_s_e.html#a5d3d779158876f9def507bdad79037be", null ],
    [ "referencia_carregadorClasse", "struct_d_a_d_o_s___c_l_a_s_s_e.html#af50666164c0a79d63ff831010e8318c9", null ],
    [ "runtime_constant_pool", "struct_d_a_d_o_s___c_l_a_s_s_e.html#a0c018490460fc694fc1bcdeddbd49e02", null ],
    [ "variaveisClasse", "struct_d_a_d_o_s___c_l_a_s_s_e.html#a61814affa4242c9de4ab4380163ae315", null ]
];