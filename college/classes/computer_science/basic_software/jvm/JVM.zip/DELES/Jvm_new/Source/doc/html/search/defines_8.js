var searchData=
[
  ['jsr',['jsr',['../opcode_8h.html#ace2b7bfa1fca2da2f7ad25d02a8bbc86',1,'opcode.h']]],
  ['jsr_5fw',['jsr_w',['../opcode_8h.html#a22559f2194f9d11acdfcbe251b324695',1,'opcode.h']]]
];
