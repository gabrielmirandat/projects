var structline__number__table__type =
[
    [ "line_number", "structline__number__table__type.html#a85fe37c92e96597234cdfdad035f1ae4", null ],
    [ "start_pc", "structline__number__table__type.html#a5b5fc96901fd52be22ddc5115633ed3c", null ]
];