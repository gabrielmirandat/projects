class Example1d {

    static final int angle = 35;
    static final int length = angle * 2;
}
