// Tipush.java

public	class	Tipush{

	public	static	void	main(String args[]){
		int	a = 40;
		int	b = 300;
		int	c = -40;
		int	d = -200;
	}
}
