var searchData=
[
  ['jump',['jump',['../interpreter_8c.html#a10d49ce1dfe761db660383e2f3a3d5b2',1,'jump(METHOD_DATA *method, THREAD *thread, JVM *jvm):&#160;interpreter.c'],['../interpreter_8h.html#aaa93dc3c70b899ef2967bf00942e45b4',1,'jump(METHOD_DATA *, THREAD *, JVM *):&#160;interpreter.c']]],
  ['jvmexit',['jvmExit',['../core_8h.html#a65309fe2f949999b73fa78000ffec3c4',1,'core.h']]]
];
