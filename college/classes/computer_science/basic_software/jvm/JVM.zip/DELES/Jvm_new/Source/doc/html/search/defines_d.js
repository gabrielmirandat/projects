var searchData=
[
  ['ref_5farray',['REF_ARRAY',['../core_8h.html#a0fe85cdfdc6ac54e3d35b46683608dc4',1,'core.h']]],
  ['ref_5finst',['REF_INST',['../core_8h.html#abc89a525f57ec2bfb44ee9e48660154f',1,'core.h']]],
  ['ret',['ret',['../opcode_8h.html#ae7b1d18a435dcca5e1837205e5fc909d',1,'opcode.h']]],
  ['return_5f',['return_',['../opcode_8h.html#a638cccdcb1ce7ec07018daf98815c9c7',1,'opcode.h']]]
];
