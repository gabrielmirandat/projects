var structheap__area =
[
    [ "arrays", "structheap__area.html#ad0a53fda1a9ad727ee47d6d9a6d155ca", null ],
    [ "objects", "structheap__area.html#a65ca4dc228035e942540602c47146d29", null ]
];