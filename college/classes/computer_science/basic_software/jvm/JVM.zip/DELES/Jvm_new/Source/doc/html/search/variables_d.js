var searchData=
[
  ['principal_5fversion',['Principal_version',['../struct_classe_de_arquivo.html#a6f45d7c9f0026ebf84d4c83c46fcc547',1,'ClasseDeArquivo']]],
  ['program_5fcounter',['program_counter',['../structthread.html#ab5f04be4cab8242e674775d1538dfa43',1,'thread']]],
  ['prox',['prox',['../structoperand.html#a49e5a5dbe02eaa10b1a29b71106f9910',1,'operand::prox()'],['../structframe.html#ad5c645b97d4a17c7352bf29e7396cea4',1,'frame::prox()'],['../structthread.html#aa2c034fdf01f832556b8bf192ab57dcc',1,'thread::prox()'],['../structvariable.html#aac55069e8378041cc5049f83410d1b5d',1,'variable::prox()'],['../struct_d_a_d_o_s___c_l_a_s_s_e.html#a5d3d779158876f9def507bdad79037be',1,'DADOS_CLASSE::prox()'],['../structobject.html#adc7a300d54dbdc7f5a72f145b30ff3da',1,'object::prox()'],['../structarray.html#ac5278e82af38bcc76811769de4bd4400',1,'array::prox()']]]
];
