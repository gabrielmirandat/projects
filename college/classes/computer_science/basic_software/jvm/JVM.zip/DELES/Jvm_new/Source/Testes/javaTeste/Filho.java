 package javaTeste; 

 class Filho extends Pai
 {
 	int field_filho;

	protected int methodFilho()
	{
		return 0;
	}
 }
