var searchData=
[
  ['handler_5fpc',['handler_pc',['../structexception__table__type.html#a168dd215f7eea25beaf31316f15b48b7',1,'exception_table_type']]],
  ['heap_5fjvm',['heap_jvm',['../structjvm.html#aaa2c1b91d2f8feef91b7e1e8552a873f',1,'jvm']]],
  ['high_5fbytes',['high_bytes',['../structvalue.html#a670628f51376fadc6cd3c7aa2076dd95',1,'value::high_bytes()'],['../structconst_pool_inf.html#ab116ef79f6cae5784e038805c26f2d20',1,'constPoolInf::high_bytes()']]]
];
