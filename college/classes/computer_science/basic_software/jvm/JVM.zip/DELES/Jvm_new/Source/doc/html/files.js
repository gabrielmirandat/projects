var files =
[
    [ "checker.c", "checker_8c.html", "checker_8c" ],
    [ "checker.h", "checker_8h.html", "checker_8h" ],
    [ "core.h", "core_8h.html", "core_8h" ],
    [ "cruzeiro.c", "cruzeiro_8c.html", "cruzeiro_8c" ],
    [ "interpreter.c", "interpreter_8c.html", "interpreter_8c" ],
    [ "interpreter.h", "interpreter_8h.html", "interpreter_8h" ],
    [ "LeitExib.h", "_leit_exib_8h.html", "_leit_exib_8h" ],
    [ "LeitorExibidor.c", "_leitor_exibidor_8c.html", "_leitor_exibidor_8c" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "opcode.h", "opcode_8h.html", "opcode_8h" ]
];