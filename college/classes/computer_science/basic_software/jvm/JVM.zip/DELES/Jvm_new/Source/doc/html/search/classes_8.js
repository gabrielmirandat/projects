var searchData=
[
  ['method_5fdata',['method_data',['../structmethod__data.html',1,'']]],
  ['method_5finfo',['method_info',['../structmethod__info.html',1,'']]]
];
