var structfield__data =
[
    [ "field_descriptor", "structfield__data.html#a4611e29ce2251d6402952826983d17a1", null ],
    [ "field_name", "structfield__data.html#a54a2dc5570404dfd1130871d48e2a044", null ],
    [ "field_type", "structfield__data.html#a5cf199a1fe02916e0b0e4d27b8d3646f", null ],
    [ "info", "structfield__data.html#a216ebce6db98d903a6b50554a40459a9", null ],
    [ "modifiers", "structfield__data.html#a5d98375dcb4b589355eaf0c96a15eb12", null ],
    [ "var", "structfield__data.html#a6eb4ec12db5dba2140fff01c6d0439f8", null ]
];