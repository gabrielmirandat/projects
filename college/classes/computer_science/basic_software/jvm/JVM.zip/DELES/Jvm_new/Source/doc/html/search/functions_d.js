var searchData=
[
  ['popoperand',['popOperand',['../core_8h.html#a01ea050bc682333139b2b64e89008893',1,'core.h']]],
  ['properties',['properties',['../interpreter_8c.html#a7402e9c860e8f0bbd146841c2f20e895',1,'properties(METHOD_DATA *method, THREAD *thread, JVM *jvm):&#160;interpreter.c'],['../interpreter_8h.html#a053dbc7a36e682aaf6f202bf095ecfb1',1,'properties(METHOD_DATA *, THREAD *, JVM *):&#160;interpreter.c']]],
  ['pushoperand',['pushOperand',['../core_8h.html#ada292ff1b4724c764f4cc6ff992cce06',1,'core.h']]]
];
