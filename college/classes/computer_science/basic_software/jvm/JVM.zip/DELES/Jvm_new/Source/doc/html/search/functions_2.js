var searchData=
[
  ['carregarclasse_5f01',['carregarClasse_01',['../core_8h.html#a7c9daf914ef558b41a9d0b2d617dab86',1,'carregarClasse_01(char *, DADOS_CLASSE **, DADOS_CLASSE *, JVM *):&#160;cruzeiro.c'],['../cruzeiro_8c.html#a044f22337572729fe6a256eac0ff4820',1,'carregarClasse_01(char *nomeDoArquivoDeClasse, DADOS_CLASSE **cd, DADOS_CLASSE *carregadorClasse, JVM *jvm):&#160;cruzeiro.c']]],
  ['classinitialization',['classInitialization',['../core_8h.html#a1c9426d6a17b70527ebee8b467688fa5',1,'core.h']]],
  ['classlinkingpreparation',['classLinkingPreparation',['../core_8h.html#a91b4929cb828eb0548542c7a3decf478',1,'classLinkingPreparation(DADOS_CLASSE *, JVM *):&#160;cruzeiro.c'],['../cruzeiro_8c.html#a5a186301f1f3a10e62e93674c07c2fcc',1,'classLinkingPreparation(DADOS_CLASSE *cd, JVM *jvm):&#160;cruzeiro.c']]],
  ['classlinkingresolution',['classLinkingResolution',['../core_8h.html#af99bc13e312e4a07ce2532d2331d2fe3',1,'core.h']]],
  ['classlinkingverification',['classLinkingVerification',['../core_8h.html#a253fa443bfd7f2b86cee348ce7233035',1,'classLinkingVerification(DADOS_CLASSE *, JVM *):&#160;cruzeiro.c'],['../cruzeiro_8c.html#a63268a53fa4c29f6663370e343c7a610',1,'classLinkingVerification(DADOS_CLASSE *cd, JVM *jvm):&#160;cruzeiro.c']]],
  ['classunloading',['classUnloading',['../core_8h.html#a8c96cdaa4bfb0049ed9c2ee068803961',1,'core.h']]],
  ['createmultiarray',['createMultiArray',['../interpreter_8c.html#a1d0e06d16d097e40de348c6815dab9d4',1,'createMultiArray(ARRAY *arrayref, int32_t *count_values, uint8_t i, uint8_t dimensions, JVM *jvm):&#160;interpreter.c'],['../interpreter_8h.html#a48a6bd040e3ef57a64f57f44a5458eb5',1,'createMultiArray(ARRAY *, int32_t *, uint8_t, uint8_t, JVM *):&#160;interpreter.c']]]
];
