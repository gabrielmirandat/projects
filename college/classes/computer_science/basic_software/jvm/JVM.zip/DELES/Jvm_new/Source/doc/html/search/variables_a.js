var searchData=
[
  ['magic',['magic',['../struct_classe_de_arquivo.html#a57331bb82cd19880ff79226bb2432fae',1,'ClasseDeArquivo']]],
  ['max_5flocals',['max_locals',['../structattribute__info.html#aa55aa7b42db88ca316e1bbe038b0dd16',1,'attribute_info']]],
  ['max_5fstack',['max_stack',['../structattribute__info.html#ab617c25a5e4334c18cea3df9d2505c00',1,'attribute_info']]],
  ['method_5farea_5fjvm',['method_area_jvm',['../structjvm.html#ac8c89a213f0d332aff40faa2661b97e3',1,'jvm']]],
  ['method_5fdata',['method_data',['../struct_d_a_d_o_s___c_l_a_s_s_e.html#a75c522131e8a7325da50f22f8c373ffa',1,'DADOS_CLASSE']]],
  ['method_5fdescriptor',['method_descriptor',['../structmethod__data.html#ae4a01197c105855d2e337fb8875358a8',1,'method_data']]],
  ['method_5fname',['method_name',['../structmethod__data.html#acc4747daee0a91ee73f94422c8b833ab',1,'method_data']]],
  ['methods',['methods',['../struct_classe_de_arquivo.html#a2b6a999458d5759967527d26a3219450',1,'ClasseDeArquivo']]],
  ['min_5fversion',['Min_version',['../struct_classe_de_arquivo.html#a1a97a970253c7f8651cf450a5dbc98a7',1,'ClasseDeArquivo']]],
  ['modifiers',['modifiers',['../structfield__data.html#a5d98375dcb4b589355eaf0c96a15eb12',1,'field_data::modifiers()'],['../structmethod__data.html#a2abb22d9f683ff1163f58d9b071902bd',1,'method_data::modifiers()'],['../struct_d_a_d_o_s___c_l_a_s_s_e.html#a49b8ef228c1e9116fa30acb28a3b6402',1,'DADOS_CLASSE::modifiers()']]]
];
