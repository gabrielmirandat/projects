var struct_classe_de_arquivo =
[
    [ "attributes", "struct_classe_de_arquivo.html#a9119e38492ee3cba2075867129584f66", null ],
    [ "classe_arq", "struct_classe_de_arquivo.html#ace786690df6e3ea741a18e3b49102e2b", null ],
    [ "CONSTANTEe_pool", "struct_classe_de_arquivo.html#a41c0d5758a7188709f83876e9577e134", null ],
    [ "Cont_ConstPool", "struct_classe_de_arquivo.html#a86527645a99cde472e6ae443aaff7b4e", null ],
    [ "conts_atributos", "struct_classe_de_arquivo.html#aedc3f8105d268a28a6a02b39b28f8ddd", null ],
    [ "conts_campos", "struct_classe_de_arquivo.html#a11ed358daa97442f5d1e16f5acf4fbcc", null ],
    [ "conts_metodo", "struct_classe_de_arquivo.html#a51e6aee87a53ffaec03f9fde63b33f35", null ],
    [ "fields", "struct_classe_de_arquivo.html#a0a756640d8c9a35fb2068e4da70b0f9a", null ],
    [ "flags_acesso", "struct_classe_de_arquivo.html#a113235ae98d51c48780e11d39debf99f", null ],
    [ "interfaces", "struct_classe_de_arquivo.html#a7ab7e89f230794a963028b0e827ef878", null ],
    [ "interfaces_count", "struct_classe_de_arquivo.html#a81969140a877d9eb2eda7616c58e2a4d", null ],
    [ "magic", "struct_classe_de_arquivo.html#a57331bb82cd19880ff79226bb2432fae", null ],
    [ "methods", "struct_classe_de_arquivo.html#a2b6a999458d5759967527d26a3219450", null ],
    [ "Min_version", "struct_classe_de_arquivo.html#a1a97a970253c7f8651cf450a5dbc98a7", null ],
    [ "Principal_version", "struct_classe_de_arquivo.html#a6f45d7c9f0026ebf84d4c83c46fcc547", null ],
    [ "super_classe", "struct_classe_de_arquivo.html#a250195b0cd2dfc88bf912da18aa9d558", null ]
];