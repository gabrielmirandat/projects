var searchData=
[
  ['dados_5fclasse',['DADOS_CLASSE',['../struct_d_a_d_o_s___c_l_a_s_s_e.html',1,'']]]
];
