public class pinheiro {
    public static void main(String[] args) {
        System.out.print("         X\n");
        System.out.print("        XXX\n");
        System.out.print("       XXXXX\n");
        System.out.print("      XXXXXXX\n");
        System.out.print("     XXXXXXXXX\n");
        System.out.print("    XXXXXXXXXXX\n");
        System.out.print("   XXXXXXXXXXXXX\n");
        System.out.print("  XXXXXXXXXXXXXXX\n");
        System.out.print("        XX\n");
        System.out.print("        XX\n");
        System.out.print("       XXXX\n");
                
    }
}
