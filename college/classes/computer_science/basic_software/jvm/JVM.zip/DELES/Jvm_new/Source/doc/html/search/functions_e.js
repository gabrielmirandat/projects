var searchData=
[
  ['read1byte',['read1Byte',['../_leit_exib_8h.html#a5f6526b62ca341c8fe70c117ea0bba57',1,'read1Byte(FILE *):&#160;LeitorExibidor.c'],['../_leitor_exibidor_8c.html#acd178396959c009ec7b849c928299d29',1,'read1Byte(FILE *fi):&#160;LeitorExibidor.c']]],
  ['read2byte',['read2Byte',['../_leit_exib_8h.html#ac8d6e6c9b87821a7cd27bdc0c2d36b7d',1,'read2Byte(FILE *):&#160;LeitorExibidor.c'],['../_leitor_exibidor_8c.html#a41ed338d041f0f3808f5c0fcc3f29da6',1,'read2Byte(FILE *fi):&#160;LeitorExibidor.c']]],
  ['read4byte',['read4Byte',['../_leit_exib_8h.html#a31bdf34d94418debbf1c4ae0eac05a22',1,'read4Byte(FILE *):&#160;LeitorExibidor.c'],['../_leitor_exibidor_8c.html#ac7ed0b8a152d4327637b603c9bbce4cb',1,'read4Byte(FILE *fi):&#160;LeitorExibidor.c']]]
];
