/*
    The HelloWorld class is an application that displays
   "Hello World!" to the standard output.
   */
   public class HelloWorld {

      // Display "Hello World!"
      public static void main (String args[ ]) {
         System.out.println ("Hello World!");
      }
   }
