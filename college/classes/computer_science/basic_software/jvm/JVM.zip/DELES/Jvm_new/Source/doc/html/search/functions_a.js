var searchData=
[
  ['l2t',['l2T',['../interpreter_8c.html#a739135ead120fb6081986e2cedf2dc9f',1,'l2T(METHOD_DATA *method, THREAD *thread, JVM *jvm):&#160;interpreter.c'],['../interpreter_8h.html#a9c31e4f02eb9dc3884df24df16c3b178',1,'l2T(METHOD_DATA *, THREAD *, JVM *):&#160;interpreter.c']]],
  ['ldc_5f',['ldc_',['../interpreter_8c.html#ab8ad4ed015e92554ba35534108c734cb',1,'ldc_(METHOD_DATA *method, THREAD *thread, JVM *jvm):&#160;interpreter.c'],['../interpreter_8h.html#a42f2652de9824d1a582f9e883288eb30',1,'ldc_(METHOD_DATA *, THREAD *, JVM *):&#160;interpreter.c']]],
  ['ligadordeclasse',['ligadorDeClasse',['../core_8h.html#a92753a3e4a70b1837b498b2821b1c478',1,'ligadorDeClasse(DADOS_CLASSE *, JVM *):&#160;cruzeiro.c'],['../cruzeiro_8c.html#aa6c77c38ce0e50b4e897fa2470abfca7',1,'ligadorDeClasse(DADOS_CLASSE *cd, JVM *jvm):&#160;cruzeiro.c']]],
  ['loadclassedearquivo',['loadClasseDeArquivo',['../_leit_exib_8h.html#a7722536746d54d82b3b46d5eb409f3da',1,'loadClasseDeArquivo(FILE *):&#160;LeitorExibidor.c'],['../_leitor_exibidor_8c.html#a6c4682d4fef1b0f8a2313c7ed36b7064',1,'loadClasseDeArquivo(FILE *fi):&#160;LeitorExibidor.c']]]
];
