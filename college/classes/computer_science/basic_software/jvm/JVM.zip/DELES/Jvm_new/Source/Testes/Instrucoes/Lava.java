class Lava {

    private int speed = 5; // 5 kilometers per hour

    void flow() {
    }
}
