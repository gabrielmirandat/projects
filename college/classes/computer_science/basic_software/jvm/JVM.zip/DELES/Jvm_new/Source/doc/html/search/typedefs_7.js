var searchData=
[
  ['jvm',['JVM',['../core_8h.html#a98bdb4b2c8aa49ba6bcd37df96469137',1,'core.h']]]
];
