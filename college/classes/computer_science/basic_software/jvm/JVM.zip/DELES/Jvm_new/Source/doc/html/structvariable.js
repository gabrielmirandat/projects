var structvariable =
[
    [ "field_reference", "structvariable.html#a49911b2c89f7f4e785091675963a3cbd", null ],
    [ "prox", "structvariable.html#aac55069e8378041cc5049f83410d1b5d", null ],
    [ "value", "structvariable.html#a163435f346185d4f2d8d05a78dde5bef", null ]
];