public class Soft {

    public static void main(String[] args) {
        int idade = 10;
        float altura = 1.50f;
        double temperatura = 32.5;
        long	pib = 1000000000;        
    }
}
