var searchData=
[
  ['pop',['pop',['../opcode_8h.html#a6a13234722161c83fd6467afed65b209',1,'opcode.h']]],
  ['pop2',['pop2',['../opcode_8h.html#a1e3b7fde917eb7f7f293ccd97cd99f2b',1,'opcode.h']]],
  ['popoperand',['popOperand',['../core_8h.html#a01ea050bc682333139b2b64e89008893',1,'core.h']]],
  ['principal_5fversion',['Principal_version',['../struct_classe_de_arquivo.html#a6f45d7c9f0026ebf84d4c83c46fcc547',1,'ClasseDeArquivo']]],
  ['program_5fcounter',['program_counter',['../structthread.html#ab5f04be4cab8242e674775d1538dfa43',1,'thread']]],
  ['properties',['properties',['../interpreter_8c.html#a7402e9c860e8f0bbd146841c2f20e895',1,'properties(METHOD_DATA *method, THREAD *thread, JVM *jvm):&#160;interpreter.c'],['../interpreter_8h.html#a053dbc7a36e682aaf6f202bf095ecfb1',1,'properties(METHOD_DATA *, THREAD *, JVM *):&#160;interpreter.c']]],
  ['prox',['prox',['../structoperand.html#a49e5a5dbe02eaa10b1a29b71106f9910',1,'operand::prox()'],['../structframe.html#ad5c645b97d4a17c7352bf29e7396cea4',1,'frame::prox()'],['../structthread.html#aa2c034fdf01f832556b8bf192ab57dcc',1,'thread::prox()'],['../structvariable.html#aac55069e8378041cc5049f83410d1b5d',1,'variable::prox()'],['../struct_d_a_d_o_s___c_l_a_s_s_e.html#a5d3d779158876f9def507bdad79037be',1,'DADOS_CLASSE::prox()'],['../structobject.html#adc7a300d54dbdc7f5a72f145b30ff3da',1,'object::prox()'],['../structarray.html#ac5278e82af38bcc76811769de4bd4400',1,'array::prox()']]],
  ['pushoperand',['pushOperand',['../core_8h.html#ada292ff1b4724c764f4cc6ff992cce06',1,'core.h']]],
  ['putfield',['putfield',['../opcode_8h.html#a173f3f625ebcafcd523aa0faa4cc8e79',1,'opcode.h']]],
  ['putstatic',['putstatic',['../opcode_8h.html#a8fcfdcfe7225d59ba405d724f623d588',1,'opcode.h']]]
];
