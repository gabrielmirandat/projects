public class MaxSeconds {
   public static final int MAX_SECONDS = 25;
}
