var searchData=
[
  ['value',['VALUE',['../core_8h.html#ad5d0e2bb91a9e28f920452e088b6462b',1,'core.h']]],
  ['variable',['VARIABLE',['../core_8h.html#a85b40991452ad00efae1784148c94402',1,'core.h']]]
];
