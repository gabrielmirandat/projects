var searchData=
[
  ['read1byte',['read1Byte',['../_leit_exib_8h.html#a5f6526b62ca341c8fe70c117ea0bba57',1,'read1Byte(FILE *):&#160;LeitorExibidor.c'],['../_leitor_exibidor_8c.html#acd178396959c009ec7b849c928299d29',1,'read1Byte(FILE *fi):&#160;LeitorExibidor.c']]],
  ['read2byte',['read2Byte',['../_leit_exib_8h.html#ac8d6e6c9b87821a7cd27bdc0c2d36b7d',1,'read2Byte(FILE *):&#160;LeitorExibidor.c'],['../_leitor_exibidor_8c.html#a41ed338d041f0f3808f5c0fcc3f29da6',1,'read2Byte(FILE *fi):&#160;LeitorExibidor.c']]],
  ['read4byte',['read4Byte',['../_leit_exib_8h.html#a31bdf34d94418debbf1c4ae0eac05a22',1,'read4Byte(FILE *):&#160;LeitorExibidor.c'],['../_leitor_exibidor_8c.html#ac7ed0b8a152d4327637b603c9bbce4cb',1,'read4Byte(FILE *fi):&#160;LeitorExibidor.c']]],
  ['ref',['Ref',['../structconst_pool_inf.html#ad0c502e47bccc75b8e939e5ccd1a8a16',1,'constPoolInf']]],
  ['ref_5farray',['REF_ARRAY',['../core_8h.html#a0fe85cdfdc6ac54e3d35b46683608dc4',1,'core.h']]],
  ['ref_5finst',['REF_INST',['../core_8h.html#abc89a525f57ec2bfb44ee9e48660154f',1,'core.h']]],
  ['reference',['reference',['../structvalue.html#ab277933041ff972104180fda5190a425',1,'value::reference()'],['../structvalue.html#a97a92c9e274a9166f7ae32164a06fe1d',1,'value::reference()']]],
  ['referencia_5fcarregadorclasse',['referencia_carregadorClasse',['../struct_d_a_d_o_s___c_l_a_s_s_e.html#af50666164c0a79d63ff831010e8318c9',1,'DADOS_CLASSE']]],
  ['ret',['ret',['../opcode_8h.html#ae7b1d18a435dcca5e1837205e5fc909d',1,'opcode.h']]],
  ['return_5f',['return_',['../opcode_8h.html#a638cccdcb1ce7ec07018daf98815c9c7',1,'opcode.h']]],
  ['return_5faddress',['return_address',['../structvalue.html#ae154453352d31839cbe33fca89fc98aa',1,'value']]],
  ['returnaddress',['ReturnAddress',['../structvalue.html#a264ea0eb8eca9c9698c66c7412e8ca88',1,'value']]],
  ['runtime_5fconstant_5fpool',['runtime_constant_pool',['../struct_d_a_d_o_s___c_l_a_s_s_e.html#a0c018490460fc694fc1bcdeddbd49e02',1,'DADOS_CLASSE']]]
];
