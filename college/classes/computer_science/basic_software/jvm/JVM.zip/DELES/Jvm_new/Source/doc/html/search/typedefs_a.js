var searchData=
[
  ['obj',['obj',['../core_8h.html#a75cf109ba9d4518221445697fdbfc933',1,'core.h']]],
  ['object',['OBJECT',['../core_8h.html#ae612e57be74359cf1e07ade2d61a86a0',1,'core.h']]],
  ['opcode',['OPCODE',['../core_8h.html#ab34056db44556fbb28ffa6aff4873b4c',1,'core.h']]],
  ['operand',['OPERAND',['../core_8h.html#a57370c151bf2eefc3bd6e2d13b70e7c9',1,'core.h']]]
];
