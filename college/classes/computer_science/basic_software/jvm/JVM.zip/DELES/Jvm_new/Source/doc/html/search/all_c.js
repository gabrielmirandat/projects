var searchData=
[
  ['nameandtype',['NameAndType',['../structconst_pool_inf.html#addb54edaecbb6a09ef4799c98134332a',1,'constPoolInf']]],
  ['new',['new',['../opcode_8h.html#a1ac41480eb2e4aadd52252ee550b630a',1,'opcode.h']]],
  ['newarray',['newarray',['../opcode_8h.html#a3f4be3ddbdb1d091212a149a0b728e83',1,'opcode.h']]],
  ['newclassedearquivo',['newClasseDeArquivo',['../_leit_exib_8h.html#a8e0122942cf33a90c3efbcfe99a47d70',1,'LeitExib.h']]],
  ['nomeclasse',['nomeClasse',['../struct_d_a_d_o_s___c_l_a_s_s_e.html#aa36d42ba9b426675415d1da6c02e4420',1,'DADOS_CLASSE']]],
  ['nondefined',['nonDefined',['../interpreter_8c.html#aea85e27c58a18677d890ad102432aca4',1,'nonDefined(METHOD_DATA *method, THREAD *thread, JVM *jvm):&#160;interpreter.c'],['../interpreter_8h.html#a715c7fd53124f82988012e4f72cd1c7a',1,'nonDefined(METHOD_DATA *, THREAD *, JVM *):&#160;interpreter.c']]],
  ['nop',['nop',['../opcode_8h.html#a51158539d4d6022c9a445e78b0abfa94',1,'opcode.h']]],
  ['nop_5f',['nop_',['../interpreter_8c.html#a1479000369abdedd8c4867548645d407',1,'nop_(METHOD_DATA *method, THREAD *thread, JVM *jvm):&#160;interpreter.c'],['../interpreter_8h.html#acba86e5c11b99c8e1c429ca387c43b63',1,'nop_(METHOD_DATA *, THREAD *, JVM *):&#160;interpreter.c']]],
  ['number_5fof_5fclasses',['number_of_classes',['../structattribute__info.html#acf309770753a9a9e7cf0b91fb4dd45db',1,'attribute_info']]],
  ['number_5fof_5fexceptions',['number_of_exceptions',['../structattribute__info.html#a7c0c2c58d833f7b63d0b6ab483e537f1',1,'attribute_info']]]
];
