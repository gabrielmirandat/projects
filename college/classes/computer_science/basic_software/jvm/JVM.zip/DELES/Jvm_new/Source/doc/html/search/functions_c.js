var searchData=
[
  ['newclassedearquivo',['newClasseDeArquivo',['../_leit_exib_8h.html#a8e0122942cf33a90c3efbcfe99a47d70',1,'LeitExib.h']]],
  ['nondefined',['nonDefined',['../interpreter_8c.html#aea85e27c58a18677d890ad102432aca4',1,'nonDefined(METHOD_DATA *method, THREAD *thread, JVM *jvm):&#160;interpreter.c'],['../interpreter_8h.html#a715c7fd53124f82988012e4f72cd1c7a',1,'nonDefined(METHOD_DATA *, THREAD *, JVM *):&#160;interpreter.c']]],
  ['nop_5f',['nop_',['../interpreter_8c.html#a1479000369abdedd8c4867548645d407',1,'nop_(METHOD_DATA *method, THREAD *thread, JVM *jvm):&#160;interpreter.c'],['../interpreter_8h.html#acba86e5c11b99c8e1c429ca387c43b63',1,'nop_(METHOD_DATA *, THREAD *, JVM *):&#160;interpreter.c']]]
];
