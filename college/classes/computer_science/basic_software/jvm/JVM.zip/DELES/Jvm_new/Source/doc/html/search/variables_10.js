var searchData=
[
  ['tag',['tag',['../structconst_pool_inf.html#a6ea639ac2bd081a75fb00ee2231b5bf3',1,'constPoolInf']]],
  ['thread_5fjvm',['thread_jvm',['../structjvm.html#a95875933adbaab4bef10b00738ba0722',1,'jvm']]],
  ['type',['type',['../structvalue.html#a8193b2471a420d07d6273ea3c9653155',1,'value::type()'],['../structoperand.html#a8af3746223d14253f5b287d236f59ce4',1,'operand::type()']]]
];
