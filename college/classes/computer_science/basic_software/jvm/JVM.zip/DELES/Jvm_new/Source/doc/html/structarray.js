var structarray =
[
    [ "atype", "structarray.html#af7ebd5860861c4c445eea16d8385bee6", null ],
    [ "class_data_reference", "structarray.html#a48536838f6c8518606bb3ab53b8992c5", null ],
    [ "count", "structarray.html#ac87b36a4ba31b9d2a2bf77af4c136428", null ],
    [ "entry", "structarray.html#ae5d7e6555edc115b43c4595ab022023d", null ],
    [ "prox", "structarray.html#ac5278e82af38bcc76811769de4bd4400", null ]
];