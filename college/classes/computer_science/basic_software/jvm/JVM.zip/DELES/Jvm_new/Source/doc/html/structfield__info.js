var structfield__info =
[
    [ "attributes", "structfield__info.html#afdda114944ae5eaae78c237f99257108", null ],
    [ "conts_atributos", "structfield__info.html#a8da20a3727e18a7f1a7e59cedacaa80c", null ],
    [ "descriptor_index", "structfield__info.html#a56345eae0135047540b60ca34c91eb46", null ],
    [ "flags_acesso", "structfield__info.html#af4858fc71c02c24357fb6be046516331", null ],
    [ "indicador_nome", "structfield__info.html#a15c229849e95ecf75de50a79a3760c00", null ]
];