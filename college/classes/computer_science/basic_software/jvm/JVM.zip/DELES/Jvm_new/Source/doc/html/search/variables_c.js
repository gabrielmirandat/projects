var searchData=
[
  ['objects',['objects',['../structheap__area.html#a65ca4dc228035e942540602c47146d29',1,'heap_area']]],
  ['op_5fcodesjvm',['op_codesJVM',['../_leitor_exibidor_8c.html#adba5db0c8cb85afb280efde0183d881e',1,'LeitorExibidor.c']]],
  ['opcodesjvm',['opcodesJVM',['../interpreter_8c.html#ab085c5e8fbd11f44f0580cca27621d6e',1,'interpreter.c']]],
  ['operand_5fstack',['operand_stack',['../structframe.html#a0e69123161d7ee38be16d922f09dc320',1,'frame']]],
  ['outer_5fclass_5finfo_5findex',['outer_class_info_index',['../structclasses__type.html#a8a32528b616cd9d1cfc3278e8c942f8f',1,'classes_type']]]
];
