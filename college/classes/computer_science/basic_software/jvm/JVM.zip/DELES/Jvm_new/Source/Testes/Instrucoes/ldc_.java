// ldc_.java

public	class	ldc_{

	public	static	void	main(String args[]){
		ldc_ldc2_w();
		ldc_w();
	}
	
	static	void	ldc_ldc2_w(){
		float	a = 0;
		float	b = 1;
		float	c = 2;
		float	d = 3;
		double	e = 4;
			float	ekjea = 33;
		float	ww2b = 133;
		float	ffc = 332;
		float	ddd = 388;
		double	esee = 4344;
		float	eakjea = 333;
		float	wwa2b = 1533;
		float	ffca = 3352;
		float	deeedda = 3858;
		double	eeea = 4454;
		float	ekjaea = 353;
		float	ww2ab = 1343;
		float	ffaca = 3342;
		float	ddda = 3848;
		double	eeeaa = 4434;
		float	ekjeaaa = 343;
		float	ww2aaab = 1333;
		float	ffaaac = 3332;
		float	ddaadaa = 3388;
		double	eeaaae = 4444;
		long	faab= 796392;
	int	gaab= 97692;
	int	haab= 92;
	int	iaab= 7692;
	int	jaab= 96592;
	int	kaab= 9267;
	int	laab= 9769672;
	int	maab= 2392;
	int	naab= 37693922;
	int	oaab= 9232;
	int	paab= 92342232;
	int	qaab= 9232;
	int	raab= 3376992;
	int	saab= 92;
	int	taab= 937692;
	int	uaab= 933769;
	int	vaab= 9537692;
	int	xaab= 942;
	}
	
	long	a = 3932;
	long	b = 3592;
	long	c = 3922;	
	long	d = 3962;
	long	e = 3972;
	long	f = 3982;
	long	g = 1392;
	long	h = 21392;
	long	i = 23392;
	long	j = 3962;
	long	k = 39992;
	long	l = 37792;
	long	m = 79392;
	long	n = 103192;
	long	o = 817392;
	long	p = 83921;
	long	q = 3952;
	long	r = 393112;
	long	s = 391332;
	long	t = 3922;
	long	u = 3921;
	long	v = 3916332;
	long	x = 396222;
	long	w = 6392;
	long	y = 139222;
	long	z = 3292222;
	long	aa = 3292;
	long	ba = 329112;
	long	ca = 391112;	
	long	da = 311972;
	long	ea = 3902;
	long	fa = 94392;
	long	ga = 39352;
	long	ha = 39562;
	long	ia = 393332;
	long	ja = 393332;
	long	ka = 34492;
	long	la = 3933332;
	long	ma = 392222;
	long	na = 3392;
	long	oa = 3925;
	long	pa = 3952;
	long	qa = 3592;
	long	ra = 6392;
	long	sa = 40392;
	long	ta = 3392;
	long	ua = 3392;
	long	va = 6395432;
	long	xa = 377692;
	long	wa = 392;
	long	ya = 39462;
	long	za = 39632;
	long	aaab= 3962;
	long	baab= 334692;
	long	caab= 39542;	
	long	daab= 337692;
	long	eaab= 3392;
	long	faab= 796392;
	long	gaab= 397692;
	long	haab= 392;
	long	iaab= 397692;
	long	jaab= 396592;
	long	kaab= 39267;
	long	laab= 39769672;
	long	maab= 32392;
	long	naab= 337693922;
	long	oaab= 39232;
	long	paab= 392342232;
	long	qaab= 39232;
	long	raab= 303376992;
	long	saab= 392;
	long	taab= 3937692;
	long	uaab= 3933769;
	long	vaab= 39537692;
	long	xaab= 3942;
	long	waab= 3942;
	long	yaab= 30339492;
	long	zaab= 34376992;
	long	waaab= 37693942;
	long	yasab= 3337692;
	long	zabd= 33769;
	
	static	void	ldc_w(){
	
	int	waab= 42;
	int	yaab= 339492;
	int	zaab= 376992;
	int	waaab=7693942;
	int	yasab=337692;
	int	zabd= 3769;
	}	
}
