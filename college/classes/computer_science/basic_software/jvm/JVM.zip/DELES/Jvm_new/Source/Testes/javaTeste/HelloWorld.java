/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javaTeste;
import javaTeste.HelloWorldObject;

/**
 *
 * @author Yuri Maia
 */
public class HelloWorld {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

      HelloWorldObject a = new HelloWorldObject();
      a.executeMethod(1, 2.0f, 3l);
      int[][][] b = new int[30][20][10];

    }

}
