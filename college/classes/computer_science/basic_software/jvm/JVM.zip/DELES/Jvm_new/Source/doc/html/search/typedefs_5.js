var searchData=
[
  ['heap_5farea',['HEAP_AREA',['../core_8h.html#a8aa4d8af3cc19c82a17fa714d533cb8f',1,'core.h']]]
];
