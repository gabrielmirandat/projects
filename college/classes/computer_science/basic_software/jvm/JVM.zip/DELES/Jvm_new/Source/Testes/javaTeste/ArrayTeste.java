package javaTeste;

public class ArrayTeste {
	
	public static void main(String[] args) {
		long array[] = new long[3];
		
		array[0] = 0x123456789l;
		array[1] = 0x101010101l;
		array[2] = 0x987654321l;
	}
	
}