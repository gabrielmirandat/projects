package javaTeste;

class Heranca
{
	public static void main(String[] args)
	{
		Filho f = new Filho();
		f.methodFilho();
		f.method();
		f.method2();
		f.field_pai = 1;
	}
}
