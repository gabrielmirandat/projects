var structthread =
[
    [ "jvm_stack", "structthread.html#a45e1dff8e8c5d2981ee351857fbd765c", null ],
    [ "program_counter", "structthread.html#ab5f04be4cab8242e674775d1538dfa43", null ],
    [ "prox", "structthread.html#aa2c034fdf01f832556b8bf192ab57dcc", null ]
];