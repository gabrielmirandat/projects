var searchData=
[
  ['handleobject',['handleObject',['../interpreter_8c.html#a087a4ba00043fe2d831ccf04b183a0b5',1,'handleObject(METHOD_DATA *method, THREAD *thread, JVM *jvm):&#160;interpreter.c'],['../interpreter_8h.html#a71f70628eeae78d6f63ae10b87a0a8bf',1,'handleObject(METHOD_DATA *, THREAD *, JVM *):&#160;interpreter.c']]],
  ['handlestack',['handleStack',['../interpreter_8c.html#ac9f409a905c3c48cd6921bcb144b88ac',1,'handleStack(METHOD_DATA *method, THREAD *thread, JVM *jvm):&#160;interpreter.c'],['../interpreter_8h.html#a0464f031ce20c82df647d659529e3cbb',1,'handleStack(METHOD_DATA *, THREAD *, JVM *):&#160;interpreter.c']]]
];
