var searchData=
[
  ['jsr',['jsr',['../opcode_8h.html#ace2b7bfa1fca2da2f7ad25d02a8bbc86',1,'opcode.h']]],
  ['jsr_5fw',['jsr_w',['../opcode_8h.html#a22559f2194f9d11acdfcbe251b324695',1,'opcode.h']]],
  ['jump',['jump',['../interpreter_8c.html#a10d49ce1dfe761db660383e2f3a3d5b2',1,'jump(METHOD_DATA *method, THREAD *thread, JVM *jvm):&#160;interpreter.c'],['../interpreter_8h.html#aaa93dc3c70b899ef2967bf00942e45b4',1,'jump(METHOD_DATA *, THREAD *, JVM *):&#160;interpreter.c']]],
  ['jvm',['jvm',['../structjvm.html',1,'jvm'],['../core_8h.html#a98bdb4b2c8aa49ba6bcd37df96469137',1,'JVM():&#160;core.h']]],
  ['jvm_5fstack',['jvm_stack',['../structthread.html#a45e1dff8e8c5d2981ee351857fbd765c',1,'thread']]],
  ['jvmexit',['jvmExit',['../core_8h.html#a65309fe2f949999b73fa78000ffec3c4',1,'core.h']]]
];
