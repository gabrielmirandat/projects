package javaTeste;

class Pai
{
	int field_pai;
	boolean field_pai2;

	public void method()
	{
		int field;
	}

	protected void method2()
	{
	}

	private void method3()
	{
	}
}
