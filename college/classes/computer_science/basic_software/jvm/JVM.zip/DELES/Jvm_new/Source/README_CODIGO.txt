M�dulo:

Checker -> validador de estruturas
Cruzeiro -> iniciador da jvm, finalizador da jvm, (des)carregar classe, limpar objetos (frames, operandos e etc) 
LeitExib -> leitor exibidor 
main -> fun�ao main do codigo
opcode -> lista de opcodes das instru�oes
interpreter -> logica do interpretador com implementa�oes de instru�oes