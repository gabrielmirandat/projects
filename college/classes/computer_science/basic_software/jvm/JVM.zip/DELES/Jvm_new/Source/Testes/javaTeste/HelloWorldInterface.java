/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javaTeste;

/**
 *
 * @author Yuri Maia
 */

public interface HelloWorldInterface {
  int field = 0;
  public abstract void executeMethod(int a, float b, long c);
}