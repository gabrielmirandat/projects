package javaTeste;

public class PrintTeste {
	
	public static void main(String[] args) {
		double a = 3.0;
		boolean b = true;
		System.out.println(b);
		System.out.print(a);
		System.out.println();
		/*
		Object o = new Object();
		System.out.println(o);
		
		a = 10;
		System.out.print(a);
		System.out.print((double)a/2);*/
	}
	
}