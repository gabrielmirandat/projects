gcc -std=c99 *.c -o jvm -lm
./jvm outros/"$*".class