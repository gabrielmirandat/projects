Win: gcc -std=c99 *.c -o Cruzeiro
Linux: gcc -std=c99 *.c -o Cruzeiro -lm

Win: Cruzeiro.exe path/NomeDaClasse.class (t||a) -> t:terminal, a:arquivo, null: executa
Linux: ./Cruzeiro path/NomeDaClasse.class (t||a) -> t:terminal, a:arquivo, null: executa
