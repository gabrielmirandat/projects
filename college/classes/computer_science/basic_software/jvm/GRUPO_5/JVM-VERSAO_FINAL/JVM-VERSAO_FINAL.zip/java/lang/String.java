package	java.lang;


public		class	String{
	public	String(String str){
	}
	
	public native boolean equals(String str);
}
