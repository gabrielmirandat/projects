var searchData=
[
  ['tag',['tag',['../structconstant__pool__info.html#a50ffde9be79dd080d9e8effe3ee52d66',1,'constant_pool_info']]],
  ['this_5fclass',['this_class',['../struct_class_file.html#a4c21c3dc05b35d9a49fcb5c4596e881e',1,'ClassFile']]],
  ['thread_5fjvm',['thread_jvm',['../structjvm.html#aade0f4e972e91c82cdfae9fbef99fc12',1,'jvm']]],
  ['type',['type',['../structvalue.html#a38573ffff5f6ddd53e8c3d235c1f022c',1,'value::type()'],['../structoperand.html#a38573ffff5f6ddd53e8c3d235c1f022c',1,'operand::type()']]]
];
