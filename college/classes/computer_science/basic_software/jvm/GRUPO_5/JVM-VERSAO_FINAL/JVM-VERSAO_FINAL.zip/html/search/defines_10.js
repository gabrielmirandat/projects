var searchData=
[
  ['unknown',['UNKNOWN',['../leitor__exibidor_8h.html#ac1ae4add974b9cfc6b5aaf8a578f01ab',1,'leitor_exibidor.h']]]
];
