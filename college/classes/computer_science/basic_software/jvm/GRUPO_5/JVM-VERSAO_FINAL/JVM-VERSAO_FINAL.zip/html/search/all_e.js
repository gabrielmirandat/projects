var searchData=
[
  ['pop',['pop',['../opcodes_8h.html#a6a13234722161c83fd6467afed65b209',1,'opcodes.h']]],
  ['pop2',['pop2',['../opcodes_8h.html#a1e3b7fde917eb7f7f293ccd97cd99f2b',1,'opcodes.h']]],
  ['popoperand',['popOperand',['../jvm_8h.html#a01ea050bc682333139b2b64e89008893',1,'jvm.h']]],
  ['preparelink',['prepareLink',['../jvm_8h.html#a12cf5a26d643046e9c6c00505050c2eb',1,'jvm.h']]],
  ['printconstantclass',['printConstantClass',['../leitor__exibidor_8h.html#ad79a3a3d4e63a0e6e12910203972b661',1,'leitor_exibidor.h']]],
  ['printconstantnameandtype',['printConstantNameAndType',['../leitor__exibidor_8h.html#a5c666793587d5c2d5a78a013640be745',1,'leitor_exibidor.h']]],
  ['printconstantref',['printConstantRef',['../leitor__exibidor_8h.html#a78c53d93c0f2ef08cb0ee560ce223b49',1,'leitor_exibidor.h']]],
  ['printconstantstring',['printConstantString',['../leitor__exibidor_8h.html#a4435f4550658f71c7db95c48b13ab607',1,'leitor_exibidor.h']]],
  ['printconstutf8',['printConstUtf8',['../leitor__exibidor_8h.html#a01965d8f5dc68e0b6d13fcd1687658d2',1,'leitor_exibidor.h']]],
  ['program_5fcounter',['program_counter',['../structthread.html#ae98d55db21878ce70707476fd4b02777',1,'thread']]],
  ['properties',['properties',['../interpreter_8h.html#a053dbc7a36e682aaf6f202bf095ecfb1',1,'interpreter.h']]],
  ['pushoperand',['pushOperand',['../jvm_8h.html#ada292ff1b4724c764f4cc6ff992cce06',1,'jvm.h']]],
  ['putfield',['putfield',['../opcodes_8h.html#a173f3f625ebcafcd523aa0faa4cc8e79',1,'opcodes.h']]],
  ['putstatic',['putstatic',['../opcodes_8h.html#a8fcfdcfe7225d59ba405d724f623d588',1,'opcodes.h']]]
];
