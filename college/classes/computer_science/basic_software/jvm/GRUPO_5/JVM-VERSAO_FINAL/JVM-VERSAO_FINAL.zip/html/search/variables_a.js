var searchData=
[
  ['magic',['magic',['../struct_class_file.html#a57f54349f4fd1cbbb52058812e146af2',1,'ClassFile']]],
  ['major_5fversion',['major_version',['../struct_class_file.html#a270c0b081d256b6f01aeecca2754dfc9',1,'ClassFile']]],
  ['max_5flocals',['max_locals',['../structattribute__info.html#af773303ac5e313b24a1615994b6947af',1,'attribute_info']]],
  ['max_5fstack',['max_stack',['../structattribute__info.html#a06b442439568a2eeff783e2d0dfc1d36',1,'attribute_info']]],
  ['method_5farea_5fjvm',['method_area_jvm',['../structjvm.html#a7f4741479bab59d2721d9f3d58c5de72',1,'jvm']]],
  ['method_5fdata',['method_data',['../struct_c_l_a_s_s___d_a_t_a.html#a1745ba9db84d1ee78a4e1e5181f49fe0',1,'CLASS_DATA']]],
  ['method_5fdescriptor',['method_descriptor',['../structmethod__data.html#ab6417896adc802f668182ab05b5d8507',1,'method_data']]],
  ['method_5fname',['method_name',['../structmethod__data.html#ae014d831c2d0f5ba73aac6a506bf1e34',1,'method_data']]],
  ['methods',['methods',['../struct_class_file.html#af0fc99630af87d96f99637f77f6bb565',1,'ClassFile']]],
  ['methods_5fcount',['methods_count',['../struct_class_file.html#acf3d618060eb10392a8629829bc0f2f9',1,'ClassFile']]],
  ['minor_5fversion',['minor_version',['../struct_class_file.html#a2f11475c3693e38375dc32a06a4ec8bd',1,'ClassFile']]],
  ['modifiers',['modifiers',['../structfield__data.html#abc27a722c198411d612e9d41ca75c142',1,'field_data::modifiers()'],['../structmethod__data.html#abc27a722c198411d612e9d41ca75c142',1,'method_data::modifiers()'],['../struct_c_l_a_s_s___d_a_t_a.html#abc27a722c198411d612e9d41ca75c142',1,'CLASS_DATA::modifiers()']]]
];
