var searchData=
[
  ['getfield',['getfield',['../opcodes_8h.html#a3f6dbd4c9f72ebe0a723b91d90aa77df',1,'opcodes.h']]],
  ['getstatic',['getstatic',['../opcodes_8h.html#ad50d7df6505a183c7ce0b42071052af3',1,'opcodes.h']]],
  ['goto_5f',['goto_',['../opcodes_8h.html#a1ad697eea7480965e6a8f5a00c8b9654',1,'opcodes.h']]],
  ['goto_5fw',['goto_w',['../opcodes_8h.html#a21127fabc330ca29762cbab8ba24b47d',1,'opcodes.h']]]
];
