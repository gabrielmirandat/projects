var searchData=
[
  ['obj',['obj',['../jvm_8h.html#a75cf109ba9d4518221445697fdbfc933',1,'jvm.h']]],
  ['object',['OBJECT',['../jvm_8h.html#ae612e57be74359cf1e07ade2d61a86a0',1,'jvm.h']]],
  ['opcode',['OPCODE',['../jvm_8h.html#ab34056db44556fbb28ffa6aff4873b4c',1,'jvm.h']]],
  ['operand_5fstack',['OPERAND_STACK',['../jvm_8h.html#a1b6731fe4bef5a9a406fb5c442e1d114',1,'jvm.h']]]
];
