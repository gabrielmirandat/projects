var searchData=
[
  ['l2t',['l2T',['../interpreter_8h.html#a9c31e4f02eb9dc3884df24df16c3b178',1,'interpreter.h']]],
  ['ldc_5f',['ldc_',['../interpreter_8h.html#a42f2652de9824d1a582f9e883288eb30',1,'interpreter.h']]],
  ['linkclass',['linkClass',['../jvm_8h.html#a85571483f7cb0855634ae9b88b5d2a3d',1,'jvm.h']]],
  ['loadclass',['loadClass',['../jvm_8h.html#a3499be29f813994f00d66451c5c907df',1,'jvm.h']]]
];
