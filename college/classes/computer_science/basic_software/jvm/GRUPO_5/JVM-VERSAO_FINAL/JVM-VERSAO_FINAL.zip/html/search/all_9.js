var searchData=
[
  ['jsr',['jsr',['../opcodes_8h.html#ace2b7bfa1fca2da2f7ad25d02a8bbc86',1,'opcodes.h']]],
  ['jsr_5fw',['jsr_w',['../opcodes_8h.html#a22559f2194f9d11acdfcbe251b324695',1,'opcodes.h']]],
  ['jump',['jump',['../interpreter_8h.html#aaa93dc3c70b899ef2967bf00942e45b4',1,'interpreter.h']]],
  ['jvm',['jvm',['../structjvm.html',1,'jvm'],['../jvm_8h.html#a98bdb4b2c8aa49ba6bcd37df96469137',1,'JVM():&#160;jvm.h']]],
  ['jvm_2eh',['jvm.h',['../jvm_8h.html',1,'']]],
  ['jvm_5fstack',['jvm_stack',['../structthread.html#a49ad4fbc12ba451b77e151ddf228e398',1,'thread']]]
];
