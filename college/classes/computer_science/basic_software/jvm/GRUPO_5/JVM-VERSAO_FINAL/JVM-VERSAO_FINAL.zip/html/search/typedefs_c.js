var searchData=
[
  ['variable',['VARIABLE',['../jvm_8h.html#a85b40991452ad00efae1784148c94402',1,'jvm.h']]]
];
