var searchData=
[
  ['line_5fnumber_5ftable_5ftype',['line_number_table_type',['../leitor__exibidor_8h.html#a385aefc13eacbee340b792160ba09bdc',1,'leitor_exibidor.h']]],
  ['local_5fvariable_5ftable_5ftype',['local_variable_table_type',['../leitor__exibidor_8h.html#a79055edce006106c963ac48225747ae2',1,'leitor_exibidor.h']]]
];
