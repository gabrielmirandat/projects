var searchData=
[
  ['executemethod',['executeMethod',['../jvm_8h.html#acca3c98834d654b2db2ffadc7fef4d07',1,'jvm.h']]],
  ['exitjvm',['exitJVM',['../jvm_8h.html#adb685ce721dc2b98bd51aac0bf7cbe70',1,'jvm.h']]]
];
