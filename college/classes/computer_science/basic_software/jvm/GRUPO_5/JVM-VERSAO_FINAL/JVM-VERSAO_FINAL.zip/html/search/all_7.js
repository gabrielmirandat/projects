var searchData=
[
  ['handleobject',['handleObject',['../interpreter_8h.html#a71f70628eeae78d6f63ae10b87a0a8bf',1,'interpreter.h']]],
  ['handler_5fpc',['handler_pc',['../structexception__table__type.html#a7d0aac1d7686039ac953ba1f355bddb9',1,'exception_table_type']]],
  ['handlestack',['handleStack',['../interpreter_8h.html#a0464f031ce20c82df647d659529e3cbb',1,'interpreter.h']]],
  ['heap',['HEAP',['../jvm_8h.html#a16687b2a2d20e105d2c5169f4384023d',1,'jvm.h']]],
  ['heap_5farea',['heap_area',['../structheap__area.html',1,'']]],
  ['heap_5fjvm',['heap_jvm',['../structjvm.html#a124747ba7bc4f597d0ef75c8771bc189',1,'jvm']]],
  ['high_5fbytes',['high_bytes',['../structvalue.html#a677e5a5b33027277f1998c5e60deb902',1,'value::high_bytes()'],['../structconstant__pool__info.html#a677e5a5b33027277f1998c5e60deb902',1,'constant_pool_info::high_bytes()']]]
];
