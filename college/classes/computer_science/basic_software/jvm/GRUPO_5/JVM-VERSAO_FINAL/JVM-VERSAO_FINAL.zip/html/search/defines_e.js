var searchData=
[
  ['saload',['saload',['../opcodes_8h.html#a8a13d1603bad0e00de02a90d95fbd456',1,'opcodes.h']]],
  ['sastore',['sastore',['../opcodes_8h.html#af5b292b89971147e1ba0c20653eef21c',1,'opcodes.h']]],
  ['short',['SHORT',['../jvm_8h.html#a9fbb14850a9f176447733a089071cd70',1,'jvm.h']]],
  ['sipush',['sipush',['../opcodes_8h.html#a3dc635b550b6a83051c608590ecf7edd',1,'opcodes.h']]],
  ['source_5ffile',['SOURCE_FILE',['../leitor__exibidor_8h.html#af9169006e14a70c7dc21d9eeb4974d63',1,'leitor_exibidor.h']]],
  ['swap',['swap',['../opcodes_8h.html#a16e95c6dac9f95627fb9dbb7e9b2537b',1,'opcodes.h']]],
  ['synthetic',['SYNTHETIC',['../leitor__exibidor_8h.html#a9d36fc90c96c46a1e2c6638a285d3870',1,'leitor_exibidor.h']]]
];
