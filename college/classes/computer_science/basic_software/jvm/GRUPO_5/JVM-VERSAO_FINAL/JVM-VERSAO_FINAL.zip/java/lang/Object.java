package	java.lang;


public	class	Object{

}

