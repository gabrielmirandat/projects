var searchData=
[
  ['index',['index',['../structlocal__variable__table__type.html#a852b86a2eaee9852ada7a43e61e311a2',1,'local_variable_table_type']]],
  ['info',['info',['../structfield__data.html#a9e89deaad4697791445695e41508b87d',1,'field_data::info()'],['../structmethod__data.html#a88b80cf17d6c3829c9dc7ef3c68b578f',1,'method_data::info()']]],
  ['inner_5fclass_5faccess_5fflags',['inner_class_access_flags',['../structclasses__type.html#aabcdac8f39ede689299c2285c5bf91ca',1,'classes_type']]],
  ['inner_5fclass_5finfo_5findex',['inner_class_info_index',['../structclasses__type.html#a05f3387e66601b790be4112f49b12f1d',1,'classes_type']]],
  ['inner_5fname_5findex',['inner_name_index',['../structclasses__type.html#a130dfdea56110302afb943004a4f6f93',1,'classes_type']]],
  ['innerclasses',['InnerClasses',['../structattribute__info.html#aa56dbf1b756c9afcb8ed4d4dc929d178',1,'attribute_info']]],
  ['instance_5fclass',['instance_class',['../struct_c_l_a_s_s___d_a_t_a.html#ab44a3fc60d32e3b8295b6f35deed207a',1,'CLASS_DATA']]],
  ['instance_5fvariables',['instance_variables',['../structobject.html#afb2b67dc5b66daceb7606f0e1eb13a03',1,'object']]],
  ['instancereference',['InstanceReference',['../structvalue.html#a42b4ea8cc14a88c879e50f629100e580',1,'value']]],
  ['integer',['integer',['../structvalue.html#a3477bffe336e03340a305d0cd6189f9e',1,'value::integer()'],['../structvalue.html#ae6b8eef90527598d9c9e836df1c0905b',1,'value::Integer()']]],
  ['integer_5ffloat',['Integer_Float',['../structconstant__pool__info.html#ac3edfeebd7d0f37f57341928e280a8fc',1,'constant_pool_info']]],
  ['interfaces',['interfaces',['../struct_class_file.html#a6503b19e0942942e8b2b9737c20504c9',1,'ClassFile']]],
  ['interfaces_5fcount',['interfaces_count',['../struct_class_file.html#af1e09bc61f7c64d6520042f6e3a8f820',1,'ClassFile']]]
];
