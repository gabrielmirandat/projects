var searchData=
[
  ['name_5fand_5ftype_5findex',['name_and_type_index',['../structconstant__pool__info.html#acd42ae0637fbb79ed49fdda758f10675',1,'constant_pool_info']]],
  ['name_5findex',['name_index',['../structconstant__pool__info.html#a898a74ada625e0b227dadb02901404e6',1,'constant_pool_info::name_index()'],['../structlocal__variable__table__type.html#a898a74ada625e0b227dadb02901404e6',1,'local_variable_table_type::name_index()'],['../structfield__info.html#a898a74ada625e0b227dadb02901404e6',1,'field_info::name_index()'],['../structmethod__info.html#a898a74ada625e0b227dadb02901404e6',1,'method_info::name_index()']]],
  ['nameandtype',['NameAndType',['../structconstant__pool__info.html#a7a2ece76fc9c3ca969ec118aa6c8485c',1,'constant_pool_info']]],
  ['new',['new',['../opcodes_8h.html#a1ac41480eb2e4aadd52252ee550b630a',1,'opcodes.h']]],
  ['newarray',['newarray',['../opcodes_8h.html#a3f4be3ddbdb1d091212a149a0b728e83',1,'opcodes.h']]],
  ['next',['next',['../structoperand.html#a41ab1c1d1e29f85098d41b795f81dac2',1,'operand::next()'],['../structframe.html#afaccf442e846fb864b999ef466ca3b23',1,'frame::next()'],['../structthread.html#a61f580a4141de6d8cbde8e41f101ca9b',1,'thread::next()'],['../structvariable.html#aff82253ebb8ae50e8204d2b899d08ba0',1,'variable::next()'],['../struct_c_l_a_s_s___d_a_t_a.html#a25094177dcd4682d0d6df93aec3ce555',1,'CLASS_DATA::next()'],['../structobject.html#acf1b25e1c8f6ed18b1ce2c1d8f7d3787',1,'object::next()'],['../structarray.html#a77ca1924870bc0f629a49ae5d6a0d3bc',1,'array::next()']]],
  ['nondefined',['nonDefined',['../interpreter_8h.html#a715c7fd53124f82988012e4f72cd1c7a',1,'interpreter.h']]],
  ['nop',['nop',['../opcodes_8h.html#a51158539d4d6022c9a445e78b0abfa94',1,'opcodes.h']]],
  ['nop_5f',['nop_',['../interpreter_8h.html#acba86e5c11b99c8e1c429ca387c43b63',1,'interpreter.h']]],
  ['number_5fof_5fclasses',['number_of_classes',['../structattribute__info.html#a86c84191120bf0f85d7302574970ed90',1,'attribute_info']]],
  ['number_5fof_5fexceptions',['number_of_exceptions',['../structattribute__info.html#a12d9133964d599fbfb95c8673c40fe00',1,'attribute_info']]]
];
