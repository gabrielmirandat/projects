var searchData=
[
  ['obj',['obj',['../jvm_8h.html#a75cf109ba9d4518221445697fdbfc933',1,'jvm.h']]],
  ['object',['object',['../structobject.html',1,'object'],['../jvm_8h.html#ae612e57be74359cf1e07ade2d61a86a0',1,'OBJECT():&#160;jvm.h']]],
  ['objects',['objects',['../structheap__area.html#a3ad01f0cb31fff2f9c97549fc856b29c',1,'heap_area']]],
  ['obtainattributes',['obtainAttributes',['../leitor__exibidor_8h.html#a2e59af868e08550bbec40138c92ad162',1,'leitor_exibidor.h']]],
  ['obtainclassfile',['obtainClassFile',['../leitor__exibidor_8h.html#a71811289f6ebc724c2a0ad596114e68f',1,'leitor_exibidor.h']]],
  ['obtainconstantpool',['obtainConstantPool',['../leitor__exibidor_8h.html#ab10e6f9f39f0bd6f343752e1c21badd8',1,'leitor_exibidor.h']]],
  ['obtainfields',['obtainFields',['../leitor__exibidor_8h.html#a0eb9d8e275d1a01feb70f0d587105329',1,'leitor_exibidor.h']]],
  ['obtaininterfaces',['obtainInterfaces',['../leitor__exibidor_8h.html#a5073a9f9193bfd1252d9d0d91337bfe2',1,'leitor_exibidor.h']]],
  ['obtainmethods',['obtainMethods',['../leitor__exibidor_8h.html#a7cddb5985bf594e3944af8a29297f39b',1,'leitor_exibidor.h']]],
  ['opcode',['OPCODE',['../jvm_8h.html#ab34056db44556fbb28ffa6aff4873b4c',1,'jvm.h']]],
  ['opcodes_2eh',['opcodes.h',['../opcodes_8h.html',1,'']]],
  ['operand',['operand',['../structoperand.html',1,'']]],
  ['operand_5fstack',['operand_stack',['../structframe.html#a7b8cfcc24db46e9017e5b705187c02e6',1,'frame::operand_stack()'],['../jvm_8h.html#a1b6731fe4bef5a9a406fb5c442e1d114',1,'OPERAND_STACK():&#160;jvm.h']]],
  ['outer_5fclass_5finfo_5findex',['outer_class_info_index',['../structclasses__type.html#a7b3e1e485029da1562bbf58f7537375d',1,'classes_type']]]
];
