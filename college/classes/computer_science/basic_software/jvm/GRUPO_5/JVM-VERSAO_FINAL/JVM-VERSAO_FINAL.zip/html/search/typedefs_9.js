var searchData=
[
  ['method_5fdata',['METHOD_DATA',['../jvm_8h.html#af2592f49e52b0675aaca5850571f3999',1,'jvm.h']]],
  ['method_5finfo',['method_info',['../leitor__exibidor_8h.html#a8bb5945393748ebec11db13dc8993aa4',1,'leitor_exibidor.h']]]
];
