var searchData=
[
  ['ref',['Ref',['../structconstant__pool__info.html#a360c349452749f932ee9eb22a587765d',1,'constant_pool_info']]],
  ['ref_5farray',['REF_ARRAY',['../jvm_8h.html#a0fe85cdfdc6ac54e3d35b46683608dc4',1,'jvm.h']]],
  ['ref_5finst',['REF_INST',['../jvm_8h.html#abc89a525f57ec2bfb44ee9e48660154f',1,'jvm.h']]],
  ['reference',['reference',['../structvalue.html#ac434fecb6531bc709c99410866dc9717',1,'value::reference()'],['../structvalue.html#aac3782b39f36ee4ba49965c7ccb320a4',1,'value::reference()']]],
  ['resolvelink',['resolveLink',['../jvm_8h.html#a5974706f620c64d3e38d8b74cb402ef8',1,'jvm.h']]],
  ['ret',['ret',['../opcodes_8h.html#ae7b1d18a435dcca5e1837205e5fc909d',1,'opcodes.h']]],
  ['return_5f',['return_',['../opcodes_8h.html#a638cccdcb1ce7ec07018daf98815c9c7',1,'opcodes.h']]],
  ['return_5faddress',['return_address',['../structvalue.html#a94dc2e8798014a0e4f466907954721a7',1,'value']]],
  ['returnaddress',['ReturnAddress',['../structvalue.html#a4d7d30e5b912dacd0c9a4e20a7550111',1,'value']]],
  ['runtime_5fconstant_5fpool',['runtime_constant_pool',['../struct_c_l_a_s_s___d_a_t_a.html#ab12e7ebaea45a0f22fb767da29dc52e3',1,'CLASS_DATA']]]
];
