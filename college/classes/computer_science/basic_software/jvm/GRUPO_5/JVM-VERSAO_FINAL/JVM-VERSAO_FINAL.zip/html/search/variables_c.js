var searchData=
[
  ['objects',['objects',['../structheap__area.html#a3ad01f0cb31fff2f9c97549fc856b29c',1,'heap_area']]],
  ['operand_5fstack',['operand_stack',['../structframe.html#a7b8cfcc24db46e9017e5b705187c02e6',1,'frame']]],
  ['outer_5fclass_5finfo_5findex',['outer_class_info_index',['../structclasses__type.html#a7b3e1e485029da1562bbf58f7537375d',1,'classes_type']]]
];
