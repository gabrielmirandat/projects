var searchData=
[
  ['ref',['Ref',['../structconstant__pool__info.html#a360c349452749f932ee9eb22a587765d',1,'constant_pool_info']]],
  ['reference',['reference',['../structvalue.html#ac434fecb6531bc709c99410866dc9717',1,'value::reference()'],['../structvalue.html#aac3782b39f36ee4ba49965c7ccb320a4',1,'value::reference()']]],
  ['return_5faddress',['return_address',['../structvalue.html#a94dc2e8798014a0e4f466907954721a7',1,'value']]],
  ['returnaddress',['ReturnAddress',['../structvalue.html#a4d7d30e5b912dacd0c9a4e20a7550111',1,'value']]],
  ['runtime_5fconstant_5fpool',['runtime_constant_pool',['../struct_c_l_a_s_s___d_a_t_a.html#ab12e7ebaea45a0f22fb767da29dc52e3',1,'CLASS_DATA']]]
];
