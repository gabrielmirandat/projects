package	java.io;
import	java.lang.System;


public	class PrintStream{
	public	native	void println();
	public	native	void println(boolean x);
	public	native	void println(byte x);
	public	native	void println(char x);
	public	native	void println(short x);
	public	native	void println(int x);
	public	native	void println(float x);
	public	native	void println(long x);	
	public	native	void println(double x);
	public	native	void println(String x);
	
	public	native	void print();
	public	native	void print(boolean x);
	public	native	void print(byte x);
	public	native	void print(char x);
	public	native	void print(short x);
	public	native	void print(int x);
	public	native	void print(float x);
	public	native	void print(long x);	
	public	native	void print(double x);
	public	native	void print(String x);
 }
