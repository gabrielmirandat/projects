var searchData=
[
  ['i2t',['i2T',['../interpreter_8h.html#ad3f6580d2506431a1c9d77903b6a7919',1,'interpreter.h']]],
  ['if_5facmop',['if_acmOP',['../interpreter_8h.html#aba50f8beb9e9ea67529b3ae9bb3662f1',1,'interpreter.h']]],
  ['if_5ficmop',['if_icmOP',['../interpreter_8h.html#a64df2e5e30a1937d9db1f5035b6f4c71',1,'interpreter.h']]],
  ['ifnull',['ifNull',['../interpreter_8h.html#a3d373e29057a3e304e5d57913156f94b',1,'interpreter.h']]],
  ['ifop',['ifOP',['../interpreter_8h.html#a7378fdb70f4d735efc22ccec7dd98084',1,'interpreter.h']]],
  ['impdep',['impdep',['../interpreter_8h.html#a660ac5be5441d8fcfa846a669b497a05',1,'interpreter.h']]],
  ['initializeclass',['initializeClass',['../jvm_8h.html#aaaf1e2351bcfe4bec330910af135599f',1,'jvm.h']]],
  ['interpreter',['interpreter',['../interpreter_8h.html#a410e12f67bd7e0b00f8dd92974c892db',1,'interpreter.h']]],
  ['invoke',['invoke',['../interpreter_8h.html#ab804e07f31fd89fef7cd8022278a27fa',1,'interpreter.h']]],
  ['issuperclass',['isSuperClass',['../jvm_8h.html#a8d7ca0e5a96146606986d82139727f77',1,'jvm.h']]]
];
