var searchData=
[
  ['new',['new',['../opcodes_8h.html#a1ac41480eb2e4aadd52252ee550b630a',1,'opcodes.h']]],
  ['newarray',['newarray',['../opcodes_8h.html#a3f4be3ddbdb1d091212a149a0b728e83',1,'opcodes.h']]],
  ['nop',['nop',['../opcodes_8h.html#a51158539d4d6022c9a445e78b0abfa94',1,'opcodes.h']]]
];
