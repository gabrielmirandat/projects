var searchData=
[
  ['field_5fdata',['FIELD_DATA',['../jvm_8h.html#ad5537b62ac62d6b7f34e2303f2b84982',1,'jvm.h']]],
  ['field_5finfo',['field_info',['../leitor__exibidor_8h.html#a92465becb59d258f61da663b1a202b14',1,'leitor_exibidor.h']]],
  ['frame',['FRAME',['../jvm_8h.html#ad2c7f62ece09f452ea1a5285adcc503c',1,'jvm.h']]]
];
