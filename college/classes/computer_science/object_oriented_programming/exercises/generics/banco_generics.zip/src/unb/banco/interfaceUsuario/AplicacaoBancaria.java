package unb.banco.interfaceUsuario;

public class AplicacaoBancaria {

	public static void main(String[] args) {
		UIFactory.create();
	}

}
