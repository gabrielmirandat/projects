package unb.banco.interfaceUsuario;

public interface UI {

}
