public class ListaCursos {


		
		private RepositorioCursosArray cursos;
		private int indiceCurso;
			
		public ListaCursos() {
			cursos = new RepositorioCursosArray();
			indiceCurso = 0;
		}
		
		public boolean hasNext() {
			
			return  indiceCurso < cursos.getIndice();
		}
		
		public Curso next () {
			Curso cur = cursos.getCursos()[indiceCurso];
			indiceCurso = indiceCurso + 1;
			return cur;
		}
		
		public void insert (Curso cur) {
			cursos.inserir(cur);
			
		}



}
