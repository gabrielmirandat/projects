
public class ListaMatriculas {
	
	private RepositorioMatriculasArray matriculas;
	private int indice;
		
	public ListaMatriculas() {
		matriculas = new RepositorioMatriculasArray();
		indice = 0;
	}
	
	public boolean hasNext() {
		
		return  indice < matriculas.getIndice();
	}
	
	public Matricula next () {
		Matricula c = matriculas.getMatriculas()[indice];
		indice = indice + 1;
		return c;
	}
	
	public void insert (Matricula m) {
		matriculas.inserir(m);
		
	}

}
